# np_assignment3
